import { FiveTasksApp } from "@/components/five-tasks-app";

export default function IndexPage() {
  return <FiveTasksApp />;
}
