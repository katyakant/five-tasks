"use client";

import { cn } from "@/lib/utils";
import {
  Check,
  Coffee,
  Eraser,
  Info,
  PartyPopper,
  Pause,
  Pencil,
  Play,
  Plus,
  RotateCcw,
  Timer,
  Trash2,
  X,
} from "lucide-react";
import { useEffect, useState, useSyncExternalStore } from "react";

const MAX_TASKS = 5;
const FOCUS_MS = 25 * 60 * 1000;
const TASKS_KEY = "five-tasks:tasks:v1";
const TIMER_KEY = "five-tasks:timer:v1";
const NOTIFICATION_LIFETIME_MS = 12_000;
const MAX_TEXT_LENGTH = 200;

type Task = { id: string; text: string; done: boolean };

type FocusTimer = {
  taskId: string;
  status: "running" | "paused";
  /** Абсолютное время окончания (ms) — по нему состояние восстанавливается после перезагрузки. */
  endAt: number;
  remainingMs: number;
};

type TimerNotification = { id: string; taskText: string };

type AppState = {
  tasks: Task[];
  timer: FocusTimer | null;
  notification: TimerNotification | null;
  now: number;
  hydrated: boolean;
};

const focusRing =
  "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-violet-500 focus-visible:ring-offset-2";

function createId(): string {
  if (
    typeof crypto !== "undefined" &&
    typeof crypto.randomUUID === "function"
  ) {
    return crypto.randomUUID();
  }
  return `task-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 10)}`;
}

export function formatTime(ms: number): string {
  const totalSeconds = Math.max(0, Math.ceil(ms / 1000));
  const minutes = Math.floor(totalSeconds / 60);
  const seconds = totalSeconds % 60;
  return `${String(minutes).padStart(2, "0")}:${String(seconds).padStart(2, "0")}`;
}

export function parseTasks(raw: string | null): Task[] {
  if (!raw) return [];
  let data: unknown;
  try {
    data = JSON.parse(raw);
  } catch {
    return [];
  }
  if (!Array.isArray(data)) return [];
  return data
    .filter(
      (item): item is Record<string, unknown> =>
        typeof item === "object" && item !== null,
    )
    .map((item) => ({
      id: typeof item.id === "string" ? item.id : "",
      text:
        typeof item.text === "string"
          ? item.text.slice(0, MAX_TEXT_LENGTH)
          : "",
      done: item.done === true,
    }))
    .filter((task) => task.id.length > 0 && task.text.trim().length > 0)
    .slice(0, MAX_TASKS);
}

/**
 * Восстанавливает таймер из сохранённого состояния. Если запущенный таймер
 * истёк, пока страница была закрыта, возвращается finishedTaskId — приложение
 * покажет уведомление о завершении.
 */
export function restoreTimer(
  raw: string | null,
  tasks: Task[],
  now: number,
): { timer: FocusTimer | null; finishedTaskId: string | null } {
  const empty = { timer: null, finishedTaskId: null };
  if (!raw) return empty;
  let data: unknown;
  try {
    data = JSON.parse(raw);
  } catch {
    return empty;
  }
  if (typeof data !== "object" || data === null) return empty;
  const record = data as Record<string, unknown>;
  const taskId = typeof record.taskId === "string" ? record.taskId : "";
  if (!taskId || !tasks.some((task) => task.id === taskId)) return empty;

  if (record.status === "paused") {
    const remaining =
      typeof record.remainingMs === "number" &&
      Number.isFinite(record.remainingMs)
        ? Math.min(Math.max(Math.round(record.remainingMs), 0), FOCUS_MS)
        : 0;
    if (remaining <= 0) return { timer: null, finishedTaskId: taskId };
    return {
      timer: { taskId, status: "paused", endAt: now, remainingMs: remaining },
      finishedTaskId: null,
    };
  }

  if (record.status === "running") {
    const endAt =
      typeof record.endAt === "number" && Number.isFinite(record.endAt)
        ? record.endAt
        : 0;
    if (endAt - now <= 0) return { timer: null, finishedTaskId: taskId };
    return {
      timer: { taskId, status: "running", endAt, remainingMs: endAt - now },
      finishedTaskId: null,
    };
  }

  return empty;
}

/**
 * Хранилище вне React — единственный источник правды для задач и таймера.
 * Гидрация из localStorage происходит лениво внутри getSnapshot (только на
 * клиенте): серверный и первый клиентский рендер используют одинаковый
 * SERVER_STATE, поэтому эффект с синхронным setState не нужен.
 */
const SERVER_STATE: AppState = {
  tasks: [],
  timer: null,
  notification: null,
  now: 0,
  hydrated: false,
};

let state: AppState = SERVER_STATE;
const listeners = new Set<() => void>();
let hydrated = false;

function emit() {
  for (const listener of listeners) listener();
}

function readStorage(key: string): string | null {
  try {
    return window.localStorage.getItem(key);
  } catch {
    return null;
  }
}

function persist() {
  try {
    window.localStorage.setItem(TASKS_KEY, JSON.stringify(state.tasks));
    if (state.timer) {
      window.localStorage.setItem(TIMER_KEY, JSON.stringify(state.timer));
    } else {
      window.localStorage.removeItem(TIMER_KEY);
    }
  } catch {
    // Хранилище недоступно — приложение продолжает работать в памяти.
  }
}

function hydrate() {
  if (hydrated || typeof window === "undefined") return;
  hydrated = true;
  const now = Date.now();
  const tasks = parseTasks(readStorage(TASKS_KEY));
  const { timer, finishedTaskId } = restoreTimer(
    readStorage(TIMER_KEY),
    tasks,
    now,
  );
  const notification = finishedTaskId
    ? {
        id: `${finishedTaskId}:${now}`,
        taskText:
          tasks.find((task) => task.id === finishedTaskId)?.text ?? "Задача",
      }
    : null;
  state = { tasks, timer, notification, now, hydrated: true };
  emit();
}

function subscribe(listener: () => void) {
  listeners.add(listener);
  return () => {
    listeners.delete(listener);
  };
}

function getSnapshot(): AppState {
  if (!hydrated) hydrate();
  return state;
}

function getServerSnapshot(): AppState {
  return SERVER_STATE;
}

function commit(next: Omit<AppState, "hydrated">) {
  state = { ...next, hydrated: true };
  persist();
  emit();
}

/** Обновление без записи в localStorage (например, тик часов). */
function update(next: Omit<AppState, "hydrated">) {
  state = { ...next, hydrated: true };
  emit();
}

function addTask(text: string) {
  const trimmed = text.trim().slice(0, MAX_TEXT_LENGTH);
  if (!trimmed || state.tasks.length >= MAX_TASKS) return;
  commit({
    ...state,
    tasks: [...state.tasks, { id: createId(), text: trimmed, done: false }],
    now: Date.now(),
  });
}

function toggleTask(id: string) {
  const task = state.tasks.find((item) => item.id === id);
  if (!task) return;
  const tasks = state.tasks.map((item) =>
    item.id === id ? { ...item, done: !item.done } : item,
  );
  // Таймер существует только для невыполненных задач.
  const timer = !task.done && state.timer?.taskId === id ? null : state.timer;
  commit({ ...state, tasks, timer, now: Date.now() });
}

function renameTask(id: string, text: string) {
  const trimmed = text.trim().slice(0, MAX_TEXT_LENGTH);
  if (!trimmed || !state.tasks.some((task) => task.id === id)) return;
  commit({
    ...state,
    tasks: state.tasks.map((task) =>
      task.id === id ? { ...task, text: trimmed } : task,
    ),
    now: Date.now(),
  });
}

function deleteTask(id: string) {
  if (!state.tasks.some((task) => task.id === id)) return;
  const timer = state.timer?.taskId === id ? null : state.timer;
  commit({
    ...state,
    tasks: state.tasks.filter((task) => task.id !== id),
    timer,
    now: Date.now(),
  });
}

function clearCompleted() {
  if (!state.tasks.some((task) => task.done)) return;
  const tasks = state.tasks.filter((task) => !task.done);
  const active = state.timer;
  const timer =
    active && tasks.some((task) => task.id === active.taskId) ? active : null;
  commit({ ...state, tasks, timer, now: Date.now() });
}

function startFocus(taskId: string) {
  const now = Date.now();
  // Один слот под таймер: запуск нового останавливает предыдущий.
  commit({
    ...state,
    timer: {
      taskId,
      status: "running",
      endAt: now + FOCUS_MS,
      remainingMs: FOCUS_MS,
    },
    now,
  });
}

function pauseFocus() {
  const timer = state.timer;
  if (timer?.status !== "running") return;
  const now = Date.now();
  const remainingMs = Math.max(0, timer.endAt - now);
  if (remainingMs <= 0) {
    finishTimer(now);
    return;
  }
  commit({ ...state, timer: { ...timer, status: "paused", remainingMs }, now });
}

function resumeFocus() {
  const timer = state.timer;
  if (timer?.status !== "paused") return;
  const now = Date.now();
  commit({
    ...state,
    timer: { ...timer, status: "running", endAt: now + timer.remainingMs },
    now,
  });
}

function resetFocus() {
  if (!state.timer) return;
  commit({ ...state, timer: null, now: Date.now() });
}

function finishTimer(now: number) {
  const timer = state.timer;
  if (!timer) return;
  const taskText =
    state.tasks.find((task) => task.id === timer.taskId)?.text ?? "Задача";
  commit({
    ...state,
    timer: null,
    notification: { id: `${timer.taskId}:${now}`, taskText },
    now,
  });
}

function dismissNotification() {
  if (!state.notification) return;
  update({ ...state, notification: null, now: Date.now() });
}

/** Тик интервала: обновляет часы и ловит истечение таймера. */
function tick() {
  if (!state.hydrated) return;
  const now = Date.now();
  const timer = state.timer;
  if (timer?.status === "running" && timer.endAt - now <= 0) {
    finishTimer(now);
    return;
  }
  if (timer?.status === "running") update({ ...state, now });
}

export function FiveTasksApp() {
  const { tasks, timer, notification, now, hydrated } = useSyncExternalStore(
    subscribe,
    getSnapshot,
    getServerSnapshot,
  );
  const [draft, setDraft] = useState("");
  const [showEmptyHint, setShowEmptyHint] = useState(false);
  const [editing, setEditing] = useState<{ id: string; text: string } | null>(
    null,
  );

  const running = timer?.status === "running";

  useEffect(() => {
    if (!running) return;
    const interval = window.setInterval(tick, 500);
    // Интервал в скрытой вкладке может притормаживать — при возврате на вкладку
    // проверяем время сразу, чтобы не пропустить истечение таймера.
    const onVisibilityChange = () => {
      if (document.visibilityState === "visible") tick();
    };
    document.addEventListener("visibilitychange", onVisibilityChange);
    return () => {
      window.clearInterval(interval);
      document.removeEventListener("visibilitychange", onVisibilityChange);
    };
  }, [running]);

  useEffect(() => {
    if (!notification) return;
    const timeout = window.setTimeout(
      dismissNotification,
      NOTIFICATION_LIFETIME_MS,
    );
    return () => window.clearTimeout(timeout);
  }, [notification]);

  function submitDraft() {
    const text = draft.trim();
    if (!text) {
      setShowEmptyHint(true);
      return;
    }
    addTask(text);
    setDraft("");
    setShowEmptyHint(false);
  }

  function startEdit(task: Task) {
    setEditing({ id: task.id, text: task.text });
  }

  function removeTask(id: string) {
    deleteTask(id);
    if (editing?.id === id) setEditing(null);
  }

  function saveEdit() {
    if (!editing) return;
    const text = editing.text.trim();
    if (text) renameTask(editing.id, text);
    setEditing(null);
  }

  const doneCount = tasks.filter((task) => task.done).length;
  const percent =
    tasks.length > 0 ? Math.round((doneCount / tasks.length) * 100) : 0;
  const isFull = tasks.length >= MAX_TASKS;
  const remainingMs = timer
    ? running
      ? Math.max(0, timer.endAt - now)
      : timer.remainingMs
    : 0;
  const timerPercent = Math.min(
    100,
    Math.max(0, Math.round(((FOCUS_MS - remainingMs) / FOCUS_MS) * 100)),
  );

  return (
    <div className="relative min-h-svh bg-[#faf6ef] text-stone-900">
      <div
        aria-hidden
        className="pointer-events-none absolute inset-x-0 top-0 h-72 bg-gradient-to-b from-violet-200/50 to-transparent"
      />
      <main className="relative mx-auto w-full max-w-xl px-4 pb-16 pt-10 sm:pt-16">
        <header className="text-center">
          <span className="inline-flex items-center gap-1.5 rounded-full border border-violet-200 bg-white/80 px-3 py-1 text-xs font-medium text-violet-700">
            <Timer className="h-3.5 w-3.5" aria-hidden />
            фокус-планировщик
          </span>
          <h1 className="mt-4 text-3xl font-bold tracking-tight sm:text-4xl">
            Пять дел на сегодня
          </h1>
          <p className="mx-auto mt-2 max-w-sm text-sm text-stone-500 sm:text-base">
            Максимум {MAX_TASKS} задач и 25 минут фокуса на каждую. Спокойно, по
            одной.
          </p>
        </header>

        {tasks.length > 0 && (
          <section
            aria-label="Прогресс дня"
            className="mt-8 rounded-2xl border border-stone-200/80 bg-white/80 p-4 shadow-sm sm:p-5"
          >
            <div className="flex items-baseline justify-between gap-3">
              <p className="text-sm font-semibold">
                Выполнено {doneCount} из {tasks.length}
              </p>
              <p className="text-sm font-medium tabular-nums text-violet-700">
                {percent}%
              </p>
            </div>
            <div
              role="progressbar"
              aria-valuemin={0}
              aria-valuemax={tasks.length}
              aria-valuenow={doneCount}
              aria-label={`Выполнено ${doneCount} из ${tasks.length}`}
              className="mt-2.5 h-2.5 overflow-hidden rounded-full bg-violet-100"
            >
              <div
                className="h-full rounded-full bg-gradient-to-r from-violet-500 to-violet-600 transition-[width] duration-500 motion-reduce:transition-none"
                style={{ width: `${percent}%` }}
              />
            </div>
            {doneCount > 0 && (
              <div className="mt-3 flex justify-end">
                <button
                  type="button"
                  onClick={clearCompleted}
                  className={cn(
                    "inline-flex h-9 items-center gap-1.5 rounded-lg px-3 text-sm font-medium text-stone-500 transition-colors hover:bg-stone-100 hover:text-stone-800",
                    focusRing,
                  )}
                >
                  <Eraser className="h-4 w-4" aria-hidden />
                  Очистить выполненные ({doneCount})
                </button>
              </div>
            )}
          </section>
        )}

        {isFull ? (
          <div
            role="status"
            className="mt-6 flex items-start gap-3 rounded-2xl border border-violet-200 bg-violet-50 p-4"
          >
            <Info
              className="mt-0.5 h-5 w-5 shrink-0 text-violet-600"
              aria-hidden
            />
            <p className="text-sm leading-relaxed text-violet-900">
              <span className="font-semibold">
                Уже {MAX_TASKS} задач — это максимум на день.
              </span>{" "}
              Очистите выполненные или удалите одну из задач, чтобы освободить
              место для новой.
            </p>
          </div>
        ) : (
          <div className="mt-6">
            <form
              onSubmit={(event) => {
                event.preventDefault();
                submitDraft();
              }}
              className="flex gap-2"
            >
              <input
                value={draft}
                onChange={(event) => {
                  setDraft(event.target.value);
                  if (event.target.value.trim()) setShowEmptyHint(false);
                }}
                placeholder="Что нужно сделать?"
                aria-label="Новая задача"
                maxLength={MAX_TEXT_LENGTH}
                className={cn(
                  "h-12 min-w-0 flex-1 rounded-xl border border-stone-300 bg-white px-4 text-[15px] shadow-sm placeholder:text-stone-400 focus:border-violet-400 focus:outline-none focus:ring-2 focus:ring-violet-300",
                  focusRing,
                )}
              />
              <button
                type="submit"
                disabled={!draft.trim()}
                className={cn(
                  "inline-flex h-12 shrink-0 items-center gap-2 rounded-xl bg-violet-600 px-4 text-[15px] font-semibold text-white shadow-sm transition-colors hover:bg-violet-700 active:bg-violet-800 disabled:cursor-not-allowed disabled:opacity-40 sm:px-5",
                  focusRing,
                )}
              >
                <Plus className="h-5 w-5" aria-hidden />
                Добавить
              </button>
            </form>
            {showEmptyHint && (
              <p role="status" className="mt-2 text-sm text-red-600">
                Сначала напишите задачу — пустые добавлять нельзя.
              </p>
            )}
          </div>
        )}

        <div className="mt-6">
          {hydrated ? (
            tasks.length > 0 ? (
              <ul aria-label="Список задач" className="space-y-3">
                {tasks.map((task) => {
                  const taskTimer = timer?.taskId === task.id ? timer : null;
                  const timerRunning = taskTimer?.status === "running";
                  return (
                    <li
                      key={task.id}
                      className={cn(
                        "rounded-2xl border bg-white p-3.5 shadow-sm sm:p-4",
                        task.done
                          ? "border-stone-200 bg-stone-50/80"
                          : taskTimer
                            ? "border-violet-300 shadow-md shadow-violet-600/5"
                            : "border-stone-200",
                      )}
                    >
                      <div className="flex items-start gap-3">
                        <button
                          type="button"
                          role="checkbox"
                          aria-checked={task.done}
                          aria-label={
                            task.done
                              ? "Снять отметку выполнения"
                              : "Отметить выполненной"
                          }
                          onClick={() => toggleTask(task.id)}
                          className={cn(
                            "mt-0.5 flex h-6 w-6 shrink-0 items-center justify-center rounded-md border-2 transition-colors",
                            task.done
                              ? "border-violet-600 bg-violet-600 text-white hover:bg-violet-700"
                              : "border-stone-300 bg-white hover:border-violet-400",
                            focusRing,
                          )}
                        >
                          {task.done && (
                            <Check className="h-4 w-4" aria-hidden />
                          )}
                        </button>

                        <div className="min-w-0 flex-1">
                          {editing?.id === task.id ? (
                            <input
                              autoFocus
                              value={editing.text}
                              onChange={(event) =>
                                setEditing({
                                  id: task.id,
                                  text: event.target.value,
                                })
                              }
                              onBlur={saveEdit}
                              onKeyDown={(event) => {
                                if (event.key === "Enter") {
                                  event.preventDefault();
                                  saveEdit();
                                }
                                if (event.key === "Escape") setEditing(null);
                              }}
                              aria-label="Текст задачи"
                              maxLength={MAX_TEXT_LENGTH}
                              className="w-full rounded-lg border border-violet-400 bg-white px-2.5 py-1.5 text-[15px] font-medium focus:outline-none focus:ring-2 focus:ring-violet-300"
                            />
                          ) : (
                            <p
                              className={cn(
                                "break-words py-1 text-[15px] font-medium leading-snug",
                                task.done && "text-stone-400 line-through",
                              )}
                            >
                              {task.text}
                            </p>
                          )}

                          {!task.done && !taskTimer && (
                            <button
                              type="button"
                              onClick={() => startFocus(task.id)}
                              title={
                                timer ? "Текущий таймер сбросится" : undefined
                              }
                              className={cn(
                                "mt-1.5 inline-flex h-8 items-center gap-1.5 rounded-lg border border-stone-200 bg-white px-2.5 text-xs font-medium text-stone-600 transition-colors hover:border-violet-300 hover:text-violet-700",
                                focusRing,
                              )}
                            >
                              <Play className="h-3.5 w-3.5" aria-hidden />
                              Фокус 25 мин
                            </button>
                          )}

                          {taskTimer && (
                            <div className="mt-2 rounded-xl border border-violet-200 bg-violet-50/80 p-2.5">
                              <div className="flex flex-wrap items-center gap-x-3 gap-y-2">
                                <span className="inline-flex items-center gap-1.5 text-sm font-semibold tabular-nums text-violet-700">
                                  {timerRunning ? (
                                    <Timer
                                      className="h-4 w-4 animate-pulse motion-reduce:animate-none"
                                      aria-hidden
                                    />
                                  ) : (
                                    <Pause className="h-4 w-4" aria-hidden />
                                  )}
                                  {timerRunning ? "Осталось " : "Пауза · "}
                                  {formatTime(remainingMs)}
                                </span>
                                <span className="flex-1" />
                                {timerRunning ? (
                                  <button
                                    type="button"
                                    onClick={pauseFocus}
                                    className={cn(
                                      "inline-flex h-8 items-center gap-1.5 rounded-lg bg-violet-600 px-3 text-xs font-semibold text-white transition-colors hover:bg-violet-700",
                                      focusRing,
                                    )}
                                  >
                                    <Pause
                                      className="h-3.5 w-3.5"
                                      aria-hidden
                                    />
                                    Пауза
                                  </button>
                                ) : (
                                  <button
                                    type="button"
                                    onClick={resumeFocus}
                                    className={cn(
                                      "inline-flex h-8 items-center gap-1.5 rounded-lg bg-violet-600 px-3 text-xs font-semibold text-white transition-colors hover:bg-violet-700",
                                      focusRing,
                                    )}
                                  >
                                    <Play className="h-3.5 w-3.5" aria-hidden />
                                    Продолжить
                                  </button>
                                )}
                                <button
                                  type="button"
                                  onClick={resetFocus}
                                  aria-label="Сбросить таймер"
                                  title="Сбросить"
                                  className={cn(
                                    "inline-flex h-8 w-8 items-center justify-center rounded-lg border border-violet-200 bg-white text-violet-700 transition-colors hover:bg-violet-100",
                                    focusRing,
                                  )}
                                >
                                  <RotateCcw
                                    className="h-3.5 w-3.5"
                                    aria-hidden
                                  />
                                </button>
                              </div>
                              <div className="mt-2 h-1 overflow-hidden rounded-full bg-violet-200/70">
                                <div
                                  className="h-full rounded-full bg-violet-500 transition-[width] duration-500 motion-reduce:transition-none"
                                  style={{ width: `${timerPercent}%` }}
                                />
                              </div>
                            </div>
                          )}
                        </div>

                        {editing?.id !== task.id && (
                          <div className="flex shrink-0 gap-1">
                            <button
                              type="button"
                              onClick={() => startEdit(task)}
                              aria-label="Редактировать задачу"
                              title="Редактировать"
                              className={cn(
                                "flex h-8 w-8 items-center justify-center rounded-lg text-stone-400 transition-colors hover:bg-stone-100 hover:text-violet-700",
                                focusRing,
                              )}
                            >
                              <Pencil className="h-4 w-4" aria-hidden />
                            </button>
                            <button
                              type="button"
                              onClick={() => removeTask(task.id)}
                              aria-label="Удалить задачу"
                              title="Удалить"
                              className={cn(
                                "flex h-8 w-8 items-center justify-center rounded-lg text-stone-400 transition-colors hover:bg-red-50 hover:text-red-600",
                                focusRing,
                              )}
                            >
                              <Trash2 className="h-4 w-4" aria-hidden />
                            </button>
                          </div>
                        )}
                      </div>
                    </li>
                  );
                })}
              </ul>
            ) : (
              <div className="rounded-3xl border border-dashed border-stone-300 bg-white/60 px-6 py-14 text-center">
                <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-violet-100 text-violet-600">
                  <Coffee className="h-8 w-8" aria-hidden />
                </div>
                <h2 className="mt-5 text-lg font-semibold">
                  На сегодня планов нет
                </h2>
                <p className="mx-auto mt-1.5 max-w-xs text-sm leading-relaxed text-stone-500">
                  Добавьте до {MAX_TASKS} дел — и выделите каждому 25 минут
                  спокойного фокуса.
                </p>
              </div>
            )
          ) : (
            <div
              aria-hidden
              className="h-24 animate-pulse rounded-2xl border border-stone-200/70 bg-white/60"
            />
          )}
        </div>

        <footer className="mt-10 text-center text-xs leading-relaxed text-stone-400">
          Данные хранятся только в вашем браузере — без регистрации и серверов.
        </footer>
      </main>

      {notification && (
        <div
          key={notification.id}
          role="status"
          aria-live="polite"
          className="fixed inset-x-4 bottom-4 z-50 mx-auto max-w-sm animate-in fade-in slide-in-from-bottom-4 duration-300 sm:inset-x-auto sm:left-1/2 sm:-translate-x-1/2"
        >
          <div className="flex items-start gap-3 rounded-2xl border border-violet-200 bg-white p-4 shadow-xl shadow-violet-600/10">
            <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-violet-100 text-violet-600">
              <PartyPopper className="h-5 w-5" aria-hidden />
            </div>
            <div className="min-w-0 flex-1">
              <p className="text-sm font-semibold">25 минут фокуса истекли!</p>
              <p className="mt-0.5 break-words text-sm leading-snug text-stone-500">
                «{notification.taskText}» — время вышло, сделайте паузу.
              </p>
            </div>
            <button
              type="button"
              onClick={dismissNotification}
              aria-label="Закрыть уведомление"
              className={cn(
                "flex h-8 w-8 shrink-0 items-center justify-center rounded-lg text-stone-400 transition-colors hover:bg-stone-100 hover:text-stone-700",
                focusRing,
              )}
            >
              <X className="h-4 w-4" aria-hidden />
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
